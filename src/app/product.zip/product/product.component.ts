import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ProductService } from '../Core/product.service';
import { Product } from '../Core/interface';
import { PageService } from '../Core/page.service';
import swal from 'sweetalert2';
import { ImportService } from '../Core/import.service';
import { DownloadService } from '../Core/download.service';
import { LogUtils } from '../log-utils';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  // tslint:disable-next-line:no-inferrable-types
  show: boolean = false;
  pager: any = {};
  pageSize = 10;
  pageNo: number;
  totalRecords = 0;
  productList: Array<Product> = [];
  data = {
    'hsnCode': '',
    'name': '',
    'isActive': '',
    'categoryId': '',
    'brandId': '',
    'uomId': '',
    'sortName': 'name',
    'sortType': 'desc',
    'pageSize': 10,
    'pageNo': 1
  };
  fileToUpload: any;
 
  @ViewChild('closeBtn2') closeBtn2: ElementRef;
  @ViewChild('fileInput') fileInput: ElementRef;

  //call this wherever you want to close modal
  

  private closeModal2(): void {
    this.fileInput.nativeElement.value = '';
    this.closeBtn2.nativeElement.click();
  }
  constructor(private importExcelService: ImportService,
    private downloadService: DownloadService,private productService: ProductService, private pageService: PageService) { }

  ngOnInit() {
    this.getAllProduct();
  }

  public optionpage(data) {
    this.pageSize = data.target.value;
    this.data.pageNo = 1;
    this.data.pageSize = data.target.value;
    this.getAllProduct();
    this.pager = this.pageService.getPager(this.totalRecords, 1, this.pageSize);
  }
  setPage(page: number) {
    this.pageNo = page;
    this.data.pageNo = page;
    this.getAllProduct();
    this.pager = this.pageService.getPager(this.totalRecords, page, this.pageSize);

  }

  firstPage(page: number) {
    
    this.pageNo = page;
    this.data.pageNo = page;
    
    this.pager = this.pageService.getPager(this.totalRecords, page, this.pageSize);
    


  }
  toggle() {
    this.show = !this.show;
  }
  getAllProduct() {


    this.productService.getProductList(this.data).subscribe(response => {
      this.productList = response.model;
      this.totalRecords = response.totalRecord;
      if (this.data.pageNo === 1) {
        this.firstPage(1);
      }
    },
      error => { }
    );
    
  }



  changeStatus(id){
    
    let currentStatus ;
     this.productList.filter(item=>{
      if(item.id == id)
        currentStatus = item.isActive;
    })
    // alert("row status clicked:-> "+id);

    let msg = "You want to Activate this Product?"
    let statusToShow = "Successfully Activated Product..!!"
    if(currentStatus === 1){
      msg = "You want to Deactivate this Product?"
      statusToShow = "Successfully Deactivated Product..!!"
    }

    swal({
      title: 'Are you sure?',
      text: msg,
      type: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonColor: '#d33'
    }).then((result) => {
      if(result.value){
        // call service here
        let objToDel = {
          "requestedId": id,
          "userId": 1,
          "status": currentStatus
        }
        
        this.productService.changeStatus(objToDel).subscribe(res=>{

          console.log("response received change status service:-> "+res.didError);

          if(!res.didError){
             // alert("changed successfully");
              this.getAllProduct();
              swal(
                'Info',
                statusToShow,
                'success'
              )
          }else{
            //alert("issue in changing status");

            swal(
              'Info',
              res.errorMessage,
              'warning'
            )
          }
        },err=>{
          alert("error in service");
        });
      }
    })
   
  }


  importAsXLSX() {

    const fi = this.fileInput.nativeElement;
    if (fi.files && fi.files[0]) {
      this.fileToUpload = fi.files[0];
    }
    if (this.fileToUpload) {
    this.importExcelService.uploadBrand(this.fileToUpload, 1,'api/Item/Import').subscribe(res => {

      if (res) {
        this.fileToUpload = "";
        // show swal showing total number of records uploaded
        // and download file from url
        if (!res.didError) {

          this.closeModal2();
          let  msgToDisplay = res.model.successCount + '  out of '+res.model.totalCount+' total Records imported successfully.';
          
          swal({
            title: 'Result',
            text: msgToDisplay,
            type: "success",
            showCancelButton: false,
            confirmButtonText: 'OK',
            footer: '<a href="http://103.12.132.77:6002/'+res.model.filePath+'" >click here to download details</a>'
          }).then((result) => {
            if (res.model.filePath !== null && res.model.filePath) {
               this.getAllProduct();
              // this.downloadService.downloadFile(res.model.filePath).subscribe(res1 => {
              //   console.log("response:-> " + res1);
              //   LogUtils.saveAsExcelFile(res1, 'ImportBrandResult.xlsx');

              // }, err => {
              //   console.log("error in downloading file content");
              // })
            }
          })


        } else {
          // handle here the error condition

          swal({
            title: '',
            text: res.message,
            type: "warning",
            showCancelButton: false,
            confirmButtonText: 'OK'
          })

        }


      }
    }, (err: any) => {
      //console.log(err.error.errorMessage);

     LogUtils.showLog("upload error response:-> " + err.error);
      //alert("error:-> "+err.error);

      swal({
        title: '',
        text: err.error.errorMessage,
        type: "error",
        showCancelButton: false,
        confirmButtonText: 'OK'
      });
    });
  } else {
    swal({
      title: '',
      text: 'Please select a file..!!',
      type: 'warning',
      showCancelButton: false,
      confirmButtonText: 'OK'
    });
  }
  }
}


